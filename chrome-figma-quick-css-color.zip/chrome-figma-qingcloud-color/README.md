# chrome-extensions-figma-color

> 在网页版figma上新增显示quickcss项目规范的颜色变量的chrome插件


## 使用方法

1. 进入chrome://extensions/ 
2. 点选右上角开发者模式
3. 选择该项目文件夹载入即可






